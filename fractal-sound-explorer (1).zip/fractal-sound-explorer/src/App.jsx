import { useEffect, useRef, useState } from 'react'

const vertexShaderSource = `
attribute vec2 position;
void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}
`

const fragmentShaderSource = `
precision highp float;

uniform vec2 u_resolution;
uniform vec2 u_center;
uniform float u_zoom;
uniform int u_mode;

vec3 palette(float t) {
  return 0.5 + 0.5 * cos(6.28318 * (vec3(0.0,0.33,0.67) + t));
}

void main() {
  vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / u_resolution.y;

  vec2 c = uv * u_zoom + u_center;
  vec2 z = vec2(0.0);

  if(u_mode == 1) {
    z = c;
    c = vec2(-0.8, 0.156);
  }

  int iter;
  const int MAX_ITER = 300;

  for(iter = 0; iter < MAX_ITER; iter++) {
    z = vec2(
      z.x*z.x - z.y*z.y,
      2.0*z.x*z.y
    ) + c;

    if(dot(z,z) > 4.0) break;
  }

  float t = float(iter) / float(MAX_ITER);

  vec3 col = iter == MAX_ITER
    ? vec3(0.0)
    : palette(t);

  gl_FragColor = vec4(col, 1.0);
}
`

function createShader(gl, type, source) {
  const shader = gl.createShader(type)
  gl.shaderSource(shader, source)
  gl.compileShader(shader)

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(shader))
    return null
  }

  return shader
}

function createProgram(gl, vs, fs) {
  const program = gl.createProgram()

  gl.attachShader(program, vs)
  gl.attachShader(program, fs)

  gl.linkProgram(program)

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error(gl.getProgramInfoLog(program))
    return null
  }

  return program
}

export default function App() {
  const canvasRef = useRef(null)

  const [zoom, setZoom] = useState(3.0)
  const [mode, setMode] = useState(0)

  const centerRef = useRef({ x: -0.5, y: 0 })
  const draggingRef = useRef(false)
  const lastMouseRef = useRef({ x: 0, y: 0 })

  const audioContextRef = useRef(null)
  const oscillatorRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const gl = canvas.getContext('webgl')

    if (!gl) {
      alert('WebGL not supported')
      return
    }

    function resize() {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      gl.viewport(0, 0, canvas.width, canvas.height)
    }

    resize()
    window.addEventListener('resize', resize)

    const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource)
    const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource)

    const program = createProgram(gl, vertexShader, fragmentShader)

    const vertices = new Float32Array([
      -1, -1,
       1, -1,
      -1,  1,
      -1,  1,
       1, -1,
       1,  1
    ])

    const buffer = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer)
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW)

    gl.useProgram(program)

    const position = gl.getAttribLocation(program, 'position')
    gl.enableVertexAttribArray(position)
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0)

    const resolutionLoc = gl.getUniformLocation(program, 'u_resolution')
    const centerLoc = gl.getUniformLocation(program, 'u_center')
    const zoomLoc = gl.getUniformLocation(program, 'u_zoom')
    const modeLoc = gl.getUniformLocation(program, 'u_mode')

    function render() {
      gl.uniform2f(resolutionLoc, canvas.width, canvas.height)
      gl.uniform2f(centerLoc, centerRef.current.x, centerRef.current.y)
      gl.uniform1f(zoomLoc, zoom)
      gl.uniform1i(modeLoc, mode)

      gl.drawArrays(gl.TRIANGLES, 0, 6)

      requestAnimationFrame(render)
    }

    render()

    return () => {
      window.removeEventListener('resize', resize)
    }
  }, [zoom, mode])

  function startAudio(freq) {
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioContext()
    }

    stopAudio()

    const ctx = audioContextRef.current

    const osc = ctx.createOscillator()
    const gain = ctx.createGain()

    osc.type = 'sine'
    osc.frequency.value = freq

    gain.gain.value = 0.05

    osc.connect(gain)
    gain.connect(ctx.destination)

    osc.start()

    oscillatorRef.current = osc
  }

  function stopAudio() {
    oscillatorRef.current?.stop()
    oscillatorRef.current = null
  }

  function onWheel(e) {
    e.preventDefault()

    const factor = e.deltaY > 0 ? 1.1 : 0.9
    setZoom(z => z * factor)
  }

  function onMouseDown(e) {
    draggingRef.current = true

    lastMouseRef.current = {
      x: e.clientX,
      y: e.clientY
    }

    const freq = 100 + (e.clientX / window.innerWidth) * 1000
    startAudio(freq)
  }

  function onMouseUp() {
    draggingRef.current = false
    stopAudio()
  }

  function onMouseMove(e) {
    if (!draggingRef.current) return

    const dx = e.clientX - lastMouseRef.current.x
    const dy = e.clientY - lastMouseRef.current.y

    centerRef.current.x -= dx * 0.002 * zoom
    centerRef.current.y += dy * 0.002 * zoom

    lastMouseRef.current = {
      x: e.clientX,
      y: e.clientY
    }

    if (oscillatorRef.current) {
      oscillatorRef.current.frequency.value =
        100 + (e.clientX / window.innerWidth) * 1000
    }
  }

  return (
    <div className="app">
      <canvas
        ref={canvasRef}
        onWheel={onWheel}
        onMouseDown={onMouseDown}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
        onMouseMove={onMouseMove}
      />

      <div className="ui">
        <h1>Fractal Sound Explorer</h1>

        <div className="buttons">
          <button onClick={() => setMode(0)}>
            Mandelbrot
          </button>

          <button onClick={() => setMode(1)}>
            Julia
          </button>

          <button onClick={() => {
            setZoom(3)
            centerRef.current = { x: -0.5, y: 0 }
          }}>
            Reset
          </button>
        </div>

        <p>
          Scroll to zoom. Drag to move. Hold mouse for sound.
        </p>
      </div>
    </div>
  )
}